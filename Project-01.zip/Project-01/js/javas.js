// Bx slider
	$(document).ready(function(){
	$('.slider_area').bxSlider();
	$('#main_menu').meanmenu({
		meanMenuContainer: '#mobile_menu',
		meanScreenWidth:991,
	});
});